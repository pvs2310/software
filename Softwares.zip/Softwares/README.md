# simple-crud
Crud app using only html,css and javascript.

This site is live on https://gabrielpradoc.github.io/simple-crud/
